/* Define to `unsigned long' if <sys/types.h> doesn't define.  */
#undef uintptr_t

