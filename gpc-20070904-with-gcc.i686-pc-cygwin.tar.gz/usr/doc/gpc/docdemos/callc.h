/* GPC demo program. For copying conditions see the file `COPYING.DEMO'. */

/* Actually, we wouldn't need this header file, and could instead
   put these prototypes into callc.c, unless we want to use callc.c
   also from other C source files. */

extern int foo;
extern void bar (void);
